import pytest
from django.core.exceptions import PermissionDenied, ValidationError
from django.http import Http404

from apps.projects import services
from apps.projects.models import Project, Role


def test_visibility_is_scoped_to_membership(world):
    w = world
    assert set(Project.objects.visible_to(w["eng"])) == {w["p1"]}
    assert set(Project.objects.visible_to(w["admin_a"])) == {w["p1"], w["p2"]}
    assert set(Project.objects.visible_to(w["admin_b"])) == {w["q1"]}
    assert not Project.objects.visible_to(w["outsider"]).exists()


@pytest.mark.parametrize("who", ["eng", "pm", "outsider", "admin_b"])
def test_cross_project_access_is_404_not_403(world, who):
    w = world
    target = w["q1"] if who != "admin_b" else w["p1"]
    with pytest.raises(Http404):
        services.get_project(w[who], target.pk)
    with pytest.raises(Http404):
        services.update_project(w[who], target.pk, name="hijack")
    with pytest.raises(Http404):
        services.add_member(w[who], target.pk, w[who], Role.VIEWER)


def test_malformed_id_is_404(world):
    with pytest.raises(Http404):
        services.get_project(world["eng"], "not-a-uuid")


@pytest.mark.parametrize("role", list(Role))
def test_only_project_manager_can_manage(world, make_user, role):
    w = world
    user = make_user(f"u_{role.value}")
    from apps.organizations.models import OrgMembership
    OrgMembership.objects.create(user=user, organization=w["org_a"])
    services.add_member(w["admin_a"], w["p2"].pk, user, role)
    assert services.get_project(user, w["p2"].pk) == w["p2"]  # every role can read
    if role == Role.PROJECT_MANAGER:
        assert services.update_project(user, w["p2"].pk, location="Site X").location == "Site X"
    else:
        with pytest.raises(PermissionDenied):
            services.update_project(user, w["p2"].pk, location="Site X")


def test_org_admin_manages_all_org_projects_but_only_admins_create(world):
    w = world
    assert services.update_project(w["admin_a"], w["p2"].pk, sector="Oil & gas").sector == "Oil & gas"
    with pytest.raises(PermissionDenied):
        services.create_project(w["pm"], w["org_a"], code="P9", name="Nope")


def test_cannot_add_user_from_another_organisation(world):
    w = world
    with pytest.raises(ValidationError):
        services.add_member(w["admin_a"], w["p1"].pk, w["admin_b"], Role.VIEWER)


def test_duplicate_project_code_rejected_in_org_but_allowed_across_orgs(world):
    w = world
    with pytest.raises(ValidationError):
        services.create_project(w["admin_a"], w["org_a"], code="P1", name="Dup")
    assert services.create_project(w["admin_b"], w["org_b"], code="P1", name="Same code, other org")
