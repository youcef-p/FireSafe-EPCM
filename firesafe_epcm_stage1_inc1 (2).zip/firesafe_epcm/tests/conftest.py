import pytest

from apps.accounts.models import User
from apps.organizations.models import OrgMembership, Organization
from apps.projects import services
from apps.projects.models import ProjectMembership, Role


@pytest.fixture
def make_user(db):
    def _make(name):
        return User.objects.create_user(username=name, password="x")
    return _make


@pytest.fixture
def world(make_user):
    """Two organisations, one project each, a manager and an engineer in org A, an admin in each org."""
    org_a = Organization.objects.create(name="Org A")
    org_b = Organization.objects.create(name="Org B")
    admin_a, admin_b = make_user("admin_a"), make_user("admin_b")
    pm, eng, outsider = make_user("pm"), make_user("eng"), make_user("outsider")
    OrgMembership.objects.create(user=admin_a, organization=org_a, is_admin=True)
    OrgMembership.objects.create(user=admin_b, organization=org_b, is_admin=True)
    for u in (pm, eng, outsider):
        OrgMembership.objects.create(user=u, organization=org_a)
    p1 = services.create_project(admin_a, org_a, code="P1", name="Plant 1")
    p2 = services.create_project(admin_a, org_a, code="P2", name="Plant 2")
    q1 = services.create_project(admin_b, org_b, code="Q1", name="Other firm")
    services.add_member(admin_a, p1.pk, pm, Role.PROJECT_MANAGER)
    services.add_member(admin_a, p1.pk, eng, Role.ENGINEER)
    return dict(org_a=org_a, org_b=org_b, admin_a=admin_a, admin_b=admin_b,
                pm=pm, eng=eng, outsider=outsider, p1=p1, p2=p2, q1=q1)
