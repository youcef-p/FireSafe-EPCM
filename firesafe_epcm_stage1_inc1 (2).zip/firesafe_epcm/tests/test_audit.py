import pytest
from django.db import DatabaseError, connection, transaction

from apps.audit.models import AppendOnlyError, AuditEvent
from apps.projects import services
from apps.projects.models import Role


def test_workflows_write_audit_events_with_actor_and_diff(world):
    w = world
    services.update_project(w["pm"], w["p1"].pk, name="Plant One", client="ACME")
    ev = AuditEvent.objects.get(action="project.update", project_id=w["p1"].pk)
    assert ev.actor_id == w["pm"].pk and ev.actor_label == "pm"
    assert ev.diff == {"name": ["Plant 1", "Plant One"], "client": ["", "ACME"]}
    assert AuditEvent.objects.filter(action="project.create").count() == 3
    assert AuditEvent.objects.filter(action="member.add", project_id=w["p1"].pk).count() == 2


def test_noop_update_writes_no_event(world):
    w = world
    before = AuditEvent.objects.count()
    services.update_project(w["pm"], w["p1"].pk, name="Plant 1")
    assert AuditEvent.objects.count() == before


def test_role_change_is_audited(world):
    w = world
    services.add_member(w["admin_a"], w["p1"].pk, w["eng"], Role.QAQC_ENGINEER)
    ev = AuditEvent.objects.filter(action="member.role_change").get()
    assert ev.diff["role"] == ["engineer", "qaqc_engineer"]


def test_failed_workflow_leaves_no_audit_trace(world):
    w = world
    before = AuditEvent.objects.count()
    with pytest.raises(Exception):
        services.update_project(w["eng"], w["p1"].pk, name="denied")
    assert AuditEvent.objects.count() == before


def test_audit_is_append_only_in_python(world):
    ev = AuditEvent.objects.first()
    ev.action = "tampered"
    with pytest.raises(AppendOnlyError):
        ev.save()
    with pytest.raises(AppendOnlyError):
        ev.delete()
    with pytest.raises(AppendOnlyError):
        AuditEvent.objects.update(action="x")
    with pytest.raises(AppendOnlyError):
        AuditEvent.objects.all().delete()


def test_audit_is_append_only_in_database(world):
    with connection.cursor() as cur:
        with pytest.raises(DatabaseError, match="append-only"), transaction.atomic():
            cur.execute("UPDATE audit_auditevent SET action = 'tampered'")
        with pytest.raises(DatabaseError, match="append-only"), transaction.atomic():
            cur.execute("DELETE FROM audit_auditevent")
