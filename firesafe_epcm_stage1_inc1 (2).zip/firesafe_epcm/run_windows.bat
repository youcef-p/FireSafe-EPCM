@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title FireSafe EPCM - Windows test run

rem ======================================================================
rem  FireSafe EPCM - Stage 1 increment 1 - check the database, migrate and test.
rem  Assumes Python and the packages in requirements.txt are already installed.
rem  There is no web UI in this increment, so this script verifies the domain core.
rem
rem  DATABASE, no admin rights needed:
rem   A) Portable PostgreSQL: unzip the EDB "binaries" zip next to this file so that
rem      pgsql\bin\pg_ctl.exe exists. This script then creates the data folder "pgdata",
rem      starts PostgreSQL on port 5433 (local connections only, trust login), and stops it at the end.
rem   B) Existing PostgreSQL server: leave pgsql out and set FIRESAFE_DB_HOST, FIRESAFE_DB_PORT,
rem      FIRESAFE_DB_NAME, FIRESAFE_DB_USER and FIRESAFE_DB_PASSWORD before running.
rem      The role needs the CREATEDB right because the tests create a temporary database.
rem
rem  Development defaults only. Set any variable below before running to override.
rem ======================================================================
set "PORTABLE_PG="
if exist "pgsql\bin\pg_ctl.exe" set "PORTABLE_PG=1"
if defined PORTABLE_PG if not defined FIRESAFE_DB_PORT set FIRESAFE_DB_PORT=5433

if not defined FIRESAFE_DEBUG set FIRESAFE_DEBUG=1
if not defined FIRESAFE_DB_HOST set FIRESAFE_DB_HOST=localhost
if not defined FIRESAFE_DB_PORT set FIRESAFE_DB_PORT=5432
if not defined FIRESAFE_DB_NAME set FIRESAFE_DB_NAME=firesafe
if not defined FIRESAFE_DB_USER set FIRESAFE_DB_USER=firesafe
if not defined FIRESAFE_DB_PASSWORD set FIRESAFE_DB_PASSWORD=firesafe

rem Corporate proxy. No step below uses it now; kept for later increments. Set FIRESAFE_PROXY=none to disable.
if not defined FIRESAFE_PROXY set FIRESAFE_PROXY=http://algpxynew:8080
if /i not "%FIRESAFE_PROXY%"=="none" (
    set "HTTP_PROXY=%FIRESAFE_PROXY%"
    set "HTTPS_PROXY=%FIRESAFE_PROXY%"
    set "NO_PROXY=localhost,127.0.0.1"
)

echo.
echo [1/4] Looking for Python...
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY goto :nopython

echo [2/4] Preparing the PostgreSQL database...
if defined PORTABLE_PG (
    call :startpg
    if errorlevel 1 goto :fail
)
%PY% scripts\setup_db.py
if errorlevel 1 goto :fail

echo [3/4] Applying database migrations...
%PY% manage.py migrate
if errorlevel 1 goto :fail

echo [4/4] Running automated tests...
%PY% -m pytest -q
if errorlevel 1 goto :fail

echo.
echo ALL CHECKS PASSED.
pause
call :stoppg
exit /b 0

:nopython
echo.
echo ERROR: Python was not found on PATH.
goto :fail

:fail
echo.
echo FAILED. Read the messages above, fix the problem and run this file again.
pause
call :stoppg
exit /b 1

:startpg
set "PGBIN=%~dp0pgsql\bin"
set "PGDATA=%~dp0pgdata"
set "FIRESAFE_PG_ADMIN_PASSWORD=unused-with-trust-login"
if not exist "%PGDATA%\PG_VERSION" (
    echo      Creating local data folder pgdata ...
    "%PGBIN%\initdb.exe" -D "%PGDATA%" -U postgres -A trust -E UTF8 --locale=C >nul
    if errorlevel 1 exit /b 1
)
"%PGBIN%\pg_ctl.exe" -D "%PGDATA%" status >nul 2>nul
if not errorlevel 1 exit /b 0
echo      Starting local PostgreSQL on port %FIRESAFE_DB_PORT% ...
"%PGBIN%\pg_ctl.exe" -D "%PGDATA%" -o "-p %FIRESAFE_DB_PORT%" -l "%PGDATA%\server.log" -w start >nul
if errorlevel 1 (
    echo      Could not start PostgreSQL. See pgdata\server.log
    exit /b 1
)
set "STARTED_PG=1"
exit /b 0

:stoppg
if defined STARTED_PG "%PGBIN%\pg_ctl.exe" -D "%PGDATA%" stop >nul 2>nul
exit /b 0
