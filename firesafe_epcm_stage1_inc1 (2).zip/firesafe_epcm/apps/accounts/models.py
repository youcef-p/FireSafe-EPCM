import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    language = models.CharField(
        max_length=2,
        choices=[("en", "English"), ("fr", "Français"), ("ar", "العربية")],
        default="en",
    )
