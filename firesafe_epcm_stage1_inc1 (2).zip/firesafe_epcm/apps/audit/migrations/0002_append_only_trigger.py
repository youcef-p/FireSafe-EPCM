from django.db import migrations

FORWARD = """
CREATE FUNCTION audit_auditevent_immutable() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'audit_auditevent is append-only';
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER audit_auditevent_no_change
    BEFORE UPDATE OR DELETE ON audit_auditevent
    FOR EACH ROW EXECUTE FUNCTION audit_auditevent_immutable();
"""

REVERSE = """
DROP TRIGGER audit_auditevent_no_change ON audit_auditevent;
DROP FUNCTION audit_auditevent_immutable();
"""


class Migration(migrations.Migration):
    dependencies = [("audit", "0001_initial")]
    operations = [migrations.RunSQL(FORWARD, REVERSE)]
