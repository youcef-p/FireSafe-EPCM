import uuid

from django.db import models


class AppendOnlyError(Exception):
    pass


class AuditQuerySet(models.QuerySet):
    def update(self, **kwargs):
        raise AppendOnlyError("Audit events are append-only.")

    def delete(self):
        raise AppendOnlyError("Audit events are append-only.")


class AuditEvent(models.Model):
    """Append-only. Enforced in Python here and by a PostgreSQL trigger (migration 0002)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    at = models.DateTimeField(auto_now_add=True)
    actor_id = models.UUIDField(null=True)
    actor_label = models.CharField(max_length=150, blank=True)
    organization_id = models.UUIDField(null=True)
    project_id = models.UUIDField(null=True)
    entity_type = models.CharField(max_length=60)
    entity_id = models.CharField(max_length=64)
    action = models.CharField(max_length=60)
    diff = models.JSONField(default=dict)

    objects = AuditQuerySet.as_manager()

    class Meta:
        indexes = [models.Index(fields=["project_id", "at"]), models.Index(fields=["entity_type", "entity_id"])]

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise AppendOnlyError("Audit events are append-only.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise AppendOnlyError("Audit events are append-only.")
