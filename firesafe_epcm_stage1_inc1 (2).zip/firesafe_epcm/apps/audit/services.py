from .models import AuditEvent


def record(actor, action, entity, *, diff=None, organization_id=None, project_id=None):
    return AuditEvent.objects.create(
        actor_id=getattr(actor, "pk", None),
        actor_label=getattr(actor, "get_username", lambda: "")(),
        organization_id=organization_id,
        project_id=project_id,
        entity_type=type(entity).__name__,
        entity_id=str(entity.pk),
        action=action,
        diff=diff or {},
    )
