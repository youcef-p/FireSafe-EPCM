import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.organizations.models import Organization


class Role(models.TextChoices):
    PROJECT_MANAGER = "project_manager", "Project Manager"
    ENGINEER = "engineer", "Fire Alarm / F&G Engineer"
    ENGINEERING_MANAGER = "engineering_manager", "Engineering Manager"
    DOCUMENT_CONTROLLER = "document_controller", "Document Controller"
    PROCUREMENT_ENGINEER = "procurement_engineer", "Procurement Engineer"
    CONSTRUCTION_MANAGER = "construction_manager", "Construction Manager / Supervisor"
    QAQC_ENGINEER = "qaqc_engineer", "QA/QC Engineer"
    COMMISSIONING_ENGINEER = "commissioning_engineer", "Commissioning Engineer"
    HANDOVER_ENGINEER = "handover_engineer", "Handover Engineer"
    MAINTENANCE_ENGINEER = "maintenance_engineer", "Maintenance / Asset Engineer"
    CLIENT_REPRESENTATIVE = "client_representative", "Client Representative"
    VIEWER = "viewer", "Read-only Viewer"


class ProjectQuerySet(models.QuerySet):
    def visible_to(self, user):
        """Projects the user may see: project members, plus admins of the owning organisation."""
        if not user.is_authenticated:
            return self.none()
        return self.filter(
            Q(members__user=user)
            | Q(organization__memberships__user=user, organization__memberships__is_admin=True)
        ).distinct()


class Project(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organization = models.ForeignKey(Organization, on_delete=models.PROTECT, related_name="projects")
    code = models.CharField(max_length=40)
    name = models.CharField(max_length=200)
    client = models.CharField(max_length=200, blank=True)
    location = models.CharField(max_length=200, blank=True)
    sector = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = ProjectQuerySet.as_manager()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["organization", "code"], name="uniq_project_code_per_org")]

    def __str__(self):
        return f"{self.code} {self.name}"


class ProjectMembership(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="members")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="project_memberships")
    role = models.CharField(max_length=40, choices=Role.choices)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["project", "user"], name="uniq_project_membership")]
