"""Project workflows. All access decisions live here, not in views."""
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.http import Http404

from apps.audit import services as audit
from apps.organizations.models import OrgMembership

from .models import Project, ProjectMembership, Role

EDITABLE_FIELDS = {"name", "client", "location", "sector"}


def is_org_admin(user, organization):
    return OrgMembership.objects.filter(user=user, organization=organization, is_admin=True).exists()


def can_manage(user, project):
    if is_org_admin(user, project.organization):
        return True
    return ProjectMembership.objects.filter(project=project, user=user, role=Role.PROJECT_MANAGER).exists()


def get_project(actor, pk):
    """Return a project the actor may see, else 404 (an invisible project must not reveal that it exists)."""
    try:
        return Project.objects.visible_to(actor).get(pk=pk)
    except (Project.DoesNotExist, ValidationError, ValueError):
        raise Http404("Project not found")


@transaction.atomic
def create_project(actor, organization, *, code, name, **extra):
    if not is_org_admin(actor, organization):
        raise PermissionDenied("Only organisation admins can create projects.")
    project = Project(organization=organization, code=code, name=name,
                      **{k: v for k, v in extra.items() if k in EDITABLE_FIELDS})
    project.full_clean()
    project.save()
    audit.record(actor, "project.create", project, diff={"code": code, "name": name},
                 organization_id=organization.pk, project_id=project.pk)
    return project


@transaction.atomic
def update_project(actor, project_id, **changes):
    project = get_project(actor, project_id)
    if not can_manage(actor, project):
        raise PermissionDenied("Managing a project requires the Project Manager role or organisation admin.")
    unknown = set(changes) - EDITABLE_FIELDS
    if unknown:
        raise ValidationError(f"Fields not editable: {', '.join(sorted(unknown))}")
    diff = {f: [getattr(project, f), v] for f, v in changes.items() if getattr(project, f) != v}
    for f, v in changes.items():
        setattr(project, f, v)
    project.full_clean()
    project.save()
    if diff:
        audit.record(actor, "project.update", project, diff=diff,
                     organization_id=project.organization_id, project_id=project.pk)
    return project


@transaction.atomic
def add_member(actor, project_id, user, role):
    project = get_project(actor, project_id)
    if not can_manage(actor, project):
        raise PermissionDenied("Managing members requires the Project Manager role or organisation admin.")
    if role not in Role.values:
        raise ValidationError(f"Unknown role: {role}")
    if not OrgMembership.objects.filter(user=user, organization=project.organization).exists():
        raise ValidationError("User is not a member of the project's organisation.")
    membership, created = ProjectMembership.objects.get_or_create(
        project=project, user=user, defaults={"role": role})
    previous = None if created else membership.role
    if not created and previous != role:
        membership.role = role
        membership.save()
    if created or previous != role:
        audit.record(actor, "member.add" if created else "member.role_change", membership,
                     diff={"user": str(user.pk), "role": [previous, role]},
                     organization_id=project.organization_id, project_id=project.pk)
    return membership
