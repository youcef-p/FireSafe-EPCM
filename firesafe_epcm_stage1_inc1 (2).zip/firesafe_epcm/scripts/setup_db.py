"""Create the FireSafe PostgreSQL role and database if they are missing (development/test helper).

Idempotent. If the application role can already connect, nothing is asked or changed.
Otherwise it connects as a PostgreSQL admin (default: postgres) and prompts for that password.
Settings come from the same FIRESAFE_DB_* environment variables as config/settings.py.
"""
import getpass
import os
import socket
import sys

import psycopg
from psycopg import sql

HOST = os.environ.get("FIRESAFE_DB_HOST", "localhost")
PORT = os.environ.get("FIRESAFE_DB_PORT", "5432")
NAME = os.environ.get("FIRESAFE_DB_NAME", "firesafe")
USER = os.environ.get("FIRESAFE_DB_USER", "firesafe")
PASSWORD = os.environ.get("FIRESAFE_DB_PASSWORD", "")
ADMIN_USER = os.environ.get("FIRESAFE_PG_ADMIN_USER", "postgres")


def connect(user, password, dbname, **kw):
    return psycopg.connect(host=HOST, port=PORT, user=user, password=password, dbname=dbname,
                           connect_timeout=5, **kw)


def app_role_ready():
    try:
        with connect(USER, PASSWORD, NAME) as conn:
            conn.execute("SELECT 1")
        return True
    except psycopg.Error:
        return False


def server_reachable():
    try:
        socket.create_connection((HOST, int(PORT)), timeout=5).close()
        return True
    except OSError:
        return False


def main():
    if not PASSWORD:
        sys.exit("FIRESAFE_DB_PASSWORD is not set.")
    if not server_reachable():
        sys.exit(f"No PostgreSQL server is listening on {HOST}:{PORT}. Install/start PostgreSQL "
                 "or set FIRESAFE_DB_HOST / FIRESAFE_DB_PORT.")
    if app_role_ready():
        print(f"Database '{NAME}' is ready for role '{USER}'.")
        return
    admin_pw = os.environ.get("FIRESAFE_PG_ADMIN_PASSWORD") or getpass.getpass(
        f"PostgreSQL password for admin user '{ADMIN_USER}' on {HOST}:{PORT}: ")
    try:
        conn = connect(ADMIN_USER, admin_pw, "postgres", autocommit=True)
    except psycopg.Error as exc:
        sys.exit(f"Cannot connect to PostgreSQL at {HOST}:{PORT} as '{ADMIN_USER}': {exc}")
    with conn:
        role_exists = conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (USER,)).fetchone()
        if role_exists:
            conn.execute(sql.SQL("ALTER ROLE {} CREATEDB").format(sql.Identifier(USER)))
        else:
            conn.execute(sql.SQL("CREATE ROLE {} LOGIN CREATEDB PASSWORD {}").format(
                sql.Identifier(USER), sql.Literal(PASSWORD)))
            print(f"Created role '{USER}'.")
        if not conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (NAME,)).fetchone():
            conn.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(
                sql.Identifier(NAME), sql.Identifier(USER)))
            print(f"Created database '{NAME}'.")
    if not app_role_ready():
        sys.exit(f"Role '{USER}' still cannot connect to '{NAME}'. Check FIRESAFE_DB_PASSWORD and pg_hba.conf.")
    print(f"Database '{NAME}' is ready for role '{USER}'.")


if __name__ == "__main__":
    main()
