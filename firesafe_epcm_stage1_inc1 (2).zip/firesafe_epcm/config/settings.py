"""FireSafe EPCM settings. Environment-specific values come from the environment, never from source control."""
import os
from pathlib import Path

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent

DEBUG = os.environ.get("FIRESAFE_DEBUG") == "1"
SECRET_KEY = os.environ.get("FIRESAFE_SECRET_KEY") or ("dev-only-insecure-key" if DEBUG else None)
if not SECRET_KEY:
    raise ImproperlyConfigured("Set FIRESAFE_SECRET_KEY (or FIRESAFE_DEBUG=1 for local development).")
ALLOWED_HOSTS = [h for h in os.environ.get("FIRESAFE_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h]

INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.auth",
    "apps.accounts",
    "apps.organizations",
    "apps.projects",
    "apps.audit",
]

AUTH_USER_MODEL = "accounts.User"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.environ.get("FIRESAFE_DB_NAME", "firesafe"),
        "USER": os.environ.get("FIRESAFE_DB_USER", "firesafe"),
        "PASSWORD": os.environ.get("FIRESAFE_DB_PASSWORD", ""),
        "HOST": os.environ.get("FIRESAFE_DB_HOST", "localhost"),
        "PORT": os.environ.get("FIRESAFE_DB_PORT", "5432"),
    }
}

USE_I18N = True
USE_TZ = True
LANGUAGE_CODE = "en"
LANGUAGES = [("en", "English"), ("fr", "Français"), ("ar", "العربية")]
LOCALE_PATHS = [BASE_DIR / "locale"]
TIME_ZONE = os.environ.get("FIRESAFE_TIME_ZONE", "UTC")
