import os

os.environ.setdefault("FIRESAFE_SECRET_KEY", "test-only-not-a-secret")
os.environ.setdefault("FIRESAFE_DB_PASSWORD", "firesafe")

from .settings import *  # noqa: E402,F401,F403
